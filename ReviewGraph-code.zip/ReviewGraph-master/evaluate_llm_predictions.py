from sklearn.metrics import accuracy_score, mean_absolute_error, mean_squared_error, cohen_kappa_score
import numpy as np
import pandas as pd

pred = pd.read_csv('predicted_ratings_llm2000.csv')
real = pd.read_csv('test_reviews.csv')

# Compute metrics
accuracy = accuracy_score(real['rating'], pred['predicted_rating'])
mae = mean_absolute_error(real['rating'], pred['predicted_rating'])
rmse = mean_squared_error(real['rating'], pred['predicted_rating'])
cohen_kappa = cohen_kappa_score(real['rating'], pred['predicted_rating'])

# Print results
print(f"Accuracy: {accuracy:.4f}")
print(f"MAE: {mae:.4f}")
print(f"RMSE: {rmse:.4f}")
print(f"Cohen's Kappa: {cohen_kappa:.4f}")
