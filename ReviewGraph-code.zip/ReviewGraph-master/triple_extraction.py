import json
import pickle

import transformers
from openie import StanfordOpenIE
import pandas as pd
from googletrans import Translator
from langdetect import detect
import stanfordnlp
from stanfordcorenlp import StanfordCoreNLP
import spacy
import re
import nltk
import contractions
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer
from spellchecker import SpellChecker
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
import torch
from datasets import Dataset
import bitsandbytes
from langchain_experimental.graph_transformers import LLMGraphTransformer
from langchain_core.documents import Document
from langchain_community.llms import LlamaCpp
import networkx as nx
import matplotlib.pyplot as plt
from nltk.corpus import stopwords
from neo4j import GraphDatabase
from neo4j.exceptions import CypherSyntaxError
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from simple_generation import SimpleGenerator

try:
    nltk.data.find("corpora/stopwords")
except LookupError:
    nltk.download("stopwords")

llm_called = False
min_length = 15
limit_reviews = 10000
filename = 'HotelRec.txt'
review_column_name = 'text'

synonym_list = {
    "bathrooms": "bathroom",
    "rooms": "room",
    "beds": "bed",
    "pools": "pool",
    "located": "location",
    "area": "location"
}
amenities_list = [
    "hotel", "room", "staff", "clean", "breakfast", "place", "food", "location", "service", "restaurant", "view",
    "pool", "bathroom"
]
# Define node colors
color_map = {
    'review': 'red',
    'hotel': 'purple',
    'author': 'orange',
    'word': 'skyblue'
}

stop_words = set(stopwords.words('english'))

# Change this to your Neo4j connection details
URI = "neo4j://localhost:7687"
USERNAME = "neo4j"
PASSWORD = "test1234"

# Initialize the translator
translator = Translator()

# Define the properties to include OpenIE
props = {
    'annotators': 'tokenize,ssplit,pos,lemma,depparse,natlog,openie',
    'outputFormat': 'json'
    # 'openie.triple.strict': 'true',  # Enforces stricter extraction criteria
    # 'openie.affinity_probability_cap': '0.5'  # Adjusts the clustering of extractions
}

# Define properties for NER annotation
ner_props = {
    'annotators': 'tokenize,ssplit,pos,lemma,ner',
    'outputFormat': 'json'
}

# # Enable 8-bit quantization
# bnb_config = BitsAndBytesConfig(
#     load_in_4bit=True,  # Load model in 8-bit (Reduces VRAM usage)
#     bnb_4bit_use_double_quant=True,
#     bnb_4bit_compute_dtype=torch.bfloat16,
#     llm_int8_threshold=6.0,
#     llm_int8_enable_fp32_cpu_offload=True  # Allow CPU offloading for FP32 layers
# )
#
# # Load tokenizer
# tokenizer = AutoTokenizer.from_pretrained(model_id)
#
# # Load model with 8-bit quantization
# model = AutoModelForCausalLM.from_pretrained(
#     model_id,
#     quantization_config=bnb_config,  # Use BitsAndBytes for 8-bit loading
#     torch_dtype=torch.bfloat16,
#     device_map="auto"
# )
#
# # Set up LLM pipeline
# pipeline = transformers.pipeline(
#     "text-generation",
#     model=model,
#     tokenizer=tokenizer
# )

# # Set up Langchain LLM
# llm = LlamaCpp(
#     model_path=model_path,
#     temperature=0.5,
#     max_tokens=512,
#     top_p=0.9,
#     n_ctx=2048,
#     n_batch=512,   # Increase batch size for speed
#     n_gpu_layers=35,  # Use GPU acceleration
#     verbose=True
# )
#
# llm_transformer = LLMGraphTransformer(llm=llm)


def normalize_text(text):
    text = str(text)
    text = text.lower()
    words = text.split()
    normalized_words = [synonym_list.get(word, word) for word in words]
    return " ".join(normalized_words)

def translate_review(review):
    detected_language = detect(review)
    if detected_language != 'en':
        translated = translator.translate(review, src=detected_language, dest='en')
        return translated.text

    return review


def add_space_after_period(text):
    # Regular expression to match a period not followed by a space or digit
    pattern = r'\.(?![\s\d])'
    # Substitute the matched pattern with a period followed by a space
    return re.sub(pattern, '. ', text)


def replace_proper_nouns(ner_output, replacement):
    modified_text = []
    for sentence in ner_output['sentences']:
        for token in sentence['tokens']:
            word = token['originalText']
            ner_label = token['ner']
            if ner_label == 'PERSON':
                modified_text.append(replacement)
            else:
                modified_text.append(word)
    return ' '.join(modified_text)


def spellcheck(text):
    # instantiate SpellChecker
    spell = SpellChecker()

    # split text into words
    words = text.split()

    # correct spelling of each word
    corrected_words = [spell.correction(word) if spell.correction(word) is not None else word for word in words]

    # join the corrected words back into a string
    return ' '.join(corrected_words)

def read_csv_file(filename):
    review_data = pd.read_csv(filename)
    return review_data

def read_txt_file(filename):
    # Initialize an empty list to store the parsed JSON data
    data = []

    # Read the file and parse the JSON data line by line
    with open(filename, 'r') as file:
        for i, line in enumerate(file):
            if i >= limit_reviews:
                break #stop after reaching the limit

            # Parse each line as a JSON object
            review_data = json.loads(line.strip())
            data.append(review_data)

    # Convert the list of dictionaries to a pandas DataFrame
    df = pd.DataFrame(data)
    df['Review_ID'] = df.index
    return df

def read_file(filename):
    if '.csv' in filename:
        return read_csv_file(filename)
    elif '.txt' in filename:
        return read_txt_file(filename)

def triple_extraction_stanfordopenie(review):
    # Connect to the CoreNLP server (ensure it is running)
    nlp = StanfordCoreNLP('http://localhost', port=9000, timeout=30000)

    # set up stanford openIE
    output = nlp.annotate(review, properties=props)
    review_output = json.loads(output)

    triple_list = []
    for sentence in review_output['sentences']:
        if 'openie' in sentence:
            for triple in sentence['openie']:
                subject = triple['subject']
                relation = triple['relation']
                object_ = triple['object']
                triple_list.append((subject, relation, object_))

    return triple_list

def has_numbers(inputString):
    return any(char.isdigit() for char in inputString)

# def triple_extraction_llama2_per_review(review, generator):
#     # prompt = f"""
#     # Think of yourself as efficient in deconstructing a text and precisely identifying all the entities and
#     # their interrelations. I’ll furnish you with a text, and your job is to gather all potential triples, adhering
#     # to the pattern: (subject | relationship | object)
#     #
#     # The text is as follows: "{review}"
#     #
#     # Please extract the triples and return them in the format: (subject | relationship | object).
#     # """
#
#     prompt = f"""
#     Extract all (subject|relationship|object) triples from the following review:
#
#     {review}
#
#     Provide the results in the format: (subject|relationship|object).
#     Do not repeat the same triple and ensure all extracted triples are meaningful.
#     """
#
#     # Extract the generated response
#     responses = generator([prompt], max_new_tokens=256, do_sample=True, num_beams=1, batch_size="auto")
#     print(responses[0])
#     return responses[0]

# def create_csv_triples_llama2(review_data):
#     # Input is a review_data df
#
#     # Set up the LLM model path
#     model_path = "codellama/CodeLlama-7b-hf"
#
#     # Initialize your generator
#     generator = SimpleGenerator(model_name_or_path=model_path)
#
#     review_data['extracted_triples'] = review_data[review_column_name].apply(triple_extraction_llama2_per_review, generator)
#     print(review_data)
#     save_to_csv(review_data['extracted_triples'], csv_filename='extracted_triples_llama2.csv')
#     return review_data

def create_neo4j_graph(G, uri, user, password):
    # Connect to the Neo4j database
    driver = GraphDatabase.driver(uri, auth=(user, password))

    # Open a session to run Cypher queries
    with driver.session() as session:
        # Create nodes
        for node, data in G.nodes(data=True):
            label = data.get("type", "Node")  # Default to 'Node' if type is missing
            if label[0].isdigit():
                continue

            query =f"""
                MERGE (n:{label} {{id: $id}})
                SET n += $properties
            """
            session.run(query, id=node, properties=data)

        # Create relationships
        for source, target, data in G.edges(data=True):
            relation = data.get('relation', 'RELATES_TO')

            if has_numbers(relation):
                continue

            relation = relation.replace(" ", "_")  # Replace spaces with underscores
            relation = re.sub(r'[^a-zA-Z0-9_]', '', relation)  # Remove special characters
            relation = relation.upper()

            if not relation or relation == "":
                continue

            source_label = G.nodes[source].get('type', 'Unknown')
            target_label = G.nodes[target].get('type', 'Unknown')

            query = f"""
                MATCH (a:{source_label} {{id: $source}})
                MATCH (b:{target_label} {{id: $target}})
                MERGE (a)-[r:{relation}]->(b)
                SET r += $properties
            """
            session.run(query, source=source, target=target,
                        properties=data)

def get_review_data(filename):
    # returns triple_df and review_data
    review_data = read_file(filename)

    review_data = review_data[review_data[review_column_name].str.len() >= min_length]
    review_data = review_data.sample(n=limit_reviews, random_state=42)

    review_data.to_csv(filename, index=False, encoding="utf-8")

    return review_data

def save_to_csv(triple_df, csv_filename="extracted_triples.csv"):
    # Save to CSV
    triple_df.to_csv(csv_filename, index=False, encoding="utf-8")
    print(f"Saved {len(triple_df)} triples to {csv_filename}")

def create_csv_triples_stanfordopenie(review_data):
    # initialize an empty DataFrame
    columns = ["Review_ID", "Subject", "Relation", "Object"]
    triple_df = pd.DataFrame(columns=columns)

    for index, row in review_data.iterrows():
        # assign review data
        review_id = index
        review = row[review_column_name]

        try:
            # translate the review to english (if applicable)
            review = translate_review(review)

            # expand contractions (can't to cannot)
            review = contractions.fix(review)
        except Exception as e:
            print(f"Skipping review due to error: {e}")

        # remove html newline symbols
        review = re.sub(r'<br\s*/?>', ' ', review)

        # remove hyphens and apostrophes
        review = review.replace('-', '')
        review = review.replace("'", "")
        review = review.replace("´", "")
        review = review.replace("’", "")

        # add spaces after periods, question marks, exclamation marks
        review = add_space_after_period(review)

        # extract triples
        triple_list = triple_extraction_stanfordopenie(review)

        # create a temporary DataFrame for extracted triples
        temp_df = pd.DataFrame(triple_list, columns=["Subject", "Relation", "Object"])
        temp_df["Review_ID"] = review_id  # Add the review ID

        # Append to main DataFrame
        triple_df = pd.concat([triple_df, temp_df], ignore_index=True)

    return triple_df, review_data

def create_graph(triple_df, review_data):
    # Returns graph G

    # Create a directed graph
    G = nx.DiGraph()  # Directed graph since relationships are directional

    for index, triple in triple_df.iterrows():
        review = triple['Review_ID']
        review_row = review_data[review_data['Review_ID'] == triple['Review_ID']]

        subject = normalize_text(triple['Subject'])
        relation = normalize_text(triple['Relation'])
        object = normalize_text(triple['Object'])
        sentiment = triple['Sentiment']

        if not isinstance(subject, str) or not isinstance(object, str) or not isinstance(relation, str):
            continue
        if len(subject) > 14 or len(relation) > 14 or len(object) > 14:
            continue

        # Split the string by 'Reviews-' and take the first part of the split
        hotel_name = review_row['hotel_url'].iloc[0].split('Reviews-')[1].split('.html')[0]

        # author = review_row['author'].iloc[0]

        # Add review_id node to the graph
        if not G.has_node(review):
            G.add_node(review, type='review', rating=review_row['rating'].iloc[0], date=review_row['date'])

        # Add hotel node to the graph
        if not G.has_node(hotel_name):
            G.add_node(hotel_name, type='hotel')

        # Add nodes for subject and object
        for node in [subject, object]:
            node_type = 'amenity' if node in amenities_list else 'word'

            if not G.has_node(node) or not G.has_edge(review, node):
                G.add_node(node, type=node_type)

                # Add edges from review_id to subject and object
                G.add_edge(review, node, relation='contains')

        if not G.has_edge(review, hotel_name):
            # Add edge from review to hotel
            G.add_edge(review, hotel_name, relation='reviewed')

        # Add edge between subject and object
        G.add_edge(subject, object, relation=relation, sentiment=sentiment)

    # Save the graph to a file
    with open('graph.pkl', 'wb') as f:
        pickle.dump(G, f)

    return G

def make_networkx_graph(G):
    node_colors = [color_map.get(G.nodes[n].get("type"), "gray") for n in G.nodes]

    # Visualize the Graph
    plt.figure(figsize=(12, 8))
    pos = nx.spring_layout(G, k=0.8)  # Positioning of nodes
    #pos = nx.kamada_kawai_layout(G)  # More even spacing

    # Draw Nodes
    nx.draw_networkx_nodes(G, pos, node_color=node_colors, node_size=1200, edgecolors='black')

    # Draw Edges
    nx.draw_networkx_edges(G, pos, width=2.0, edge_color='gray')

    # Edge labels (relationships)
    edge_labels = nx.get_edge_attributes(G, 'relation')
    nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels)

    # Get node labels with properties
    node_labels = {node: f"{node}\n({attrs.get('rating', '')})" for node, attrs in G.nodes(data=True)}

    # Draw labels with properties
    nx.draw_networkx_labels(G, pos, labels=node_labels, font_size=10, font_weight="bold")

def calculate_sentiments(triple_df):
    analyzer = SentimentIntensityAnalyzer()
    sentiments = []

    for index, triple in triple_df.iterrows():
        triple = str(triple['Subject']) + " " + str(triple['Relation']) + " " + str(triple['Object'])
        vs = analyzer.polarity_scores(triple)
        sentiments.append(vs['compound'])

    triple_df['Sentiment'] = sentiments
    return triple_df



review_data = get_review_data('HotelRec.csv')
print(review_data)
# triple_df = pd.read_csv('extracted_triples.csv')

#triple_df = calculate_sentiments(triple_df)
#save_to_csv(triple_df)

#G = create_graph(triple_df, review_data)

# with open('graph.pkl', 'rb') as f:
#     G = pickle.load(f)
#
# create_neo4j_graph(G, URI, USERNAME, PASSWORD)




