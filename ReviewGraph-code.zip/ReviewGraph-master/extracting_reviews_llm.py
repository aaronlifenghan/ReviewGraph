import pandas as pd

df = pd.read_csv('HotelRec.csv')

#sample training set
sampled_df = df.sample(n=2000, random_state=42)[['text', 'rating']]

test_df = df.drop(sampled_df.index)
remaining_df = df.drop(sampled_df.index)['text']

# Optionally save to separate files
sampled_df.to_csv('sampled_reviews.csv', index=False)
remaining_df.to_csv('remaining_reviews.csv', index=False)
test_df.to_csv('test_reviews.csv', index=False)

