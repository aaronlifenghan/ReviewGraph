import torch
import torch.nn.functional as F
from torch_geometric.nn import GATConv
from torch_geometric.utils import from_networkx
import networkx as nx
import numpy as np
from sklearn.model_selection import train_test_split
import pickle

with open('graph.pkl', 'rb') as f:
    G = pickle.load(f)

feature_dim = 16

# Convert graph to Pytorch Geometric data object
data = from_networkx(G)
# Make sure that the node features are a torch tensor
# (if they are not automatically processed)
data.x = torch.tensor([data.x[i] for i in range(data.num_nodes)], dtype=torch.float)

# We'll create a vector for ratings (for review nodes) and a boolean mask indicating them.
ratings = []
review_mask = []  # True for nodes that are review nodes
review_nodes = []
# Using the same node order as in the conversion from NetworkX (list(G.nodes()))
for node in list(G.nodes()):
    attr = G.nodes[node]
    # Assume review nodes have a "type" attribute equal to "review" and a "rating" attribute.
    if attr.get("type") == "review" and "rating" in attr:
        ratings.append(float(attr["rating"]))
        review_mask.append(True)
        review_nodes.append(node)
    else:
        # For non-review nodes, set a dummy value; these nodes won't contribute to the loss.
        ratings.append(0.0)
        review_mask.append(False)

# Limit to the first 100 review nodes
ratings = ratings[:100]
review_mask = review_mask[:100]
review_nodes = review_nodes[:100]

data.y = torch.tensor(ratings, dtype=torch.float)
data.review_mask = torch.tensor(review_mask, dtype=torch.bool)

class GATNet(torch.nn.Module):
    def __init__(self, input_dim, hidden_dim, heads=8):
        super(GATNet, self).__init__()
        # First GAT layer: output dimension is hidden_dim * heads when using concatenation.
        self.conv1 = GATConv(input_dim, hidden_dim, heads=heads, dropout=0.6)
        # Second GAT layer: average the outputs from the heads.
        self.conv2 = GATConv(hidden_dim * heads, hidden_dim, heads=1, concat=False, dropout=0.6)
        # Final linear layer to output a scalar rating.
        self.lin = torch.nn.Linear(hidden_dim, 1)

    def forward(self, data):
        x, edge_index = data.x, data.edge_index
        x = F.elu(self.conv1(x, edge_index))
        x = F.elu(self.conv2(x, edge_index))
        out = self.lin(x)  # Shape: [num_nodes, 1]
        return out.squeeze()  # Return as 1D tensor of shape [num_nodes]

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = GATNet(input_dim=feature_dim, hidden_dim=8, heads=8).to(device)
data = data.to(device)

optimizer = torch.optim.Adam(model.parameters(), lr=0.005, weight_decay=5e-4)
criterion = torch.nn.MSELoss()

# Extract indices corresponding to review nodes.
review_indices = data.review_mask.nonzero(as_tuple=False).view(-1)
# Split review nodes into train and test sets.
train_idx, test_idx = train_test_split(review_indices.cpu().numpy(), test_size=0.33, random_state=42)
train_idx = torch.tensor(train_idx, dtype=torch.long).to(device)
test_idx = torch.tensor(test_idx, dtype=torch.long).to(device)

model.train()
num_epochs = 200

for epoch in range(num_epochs):
    optimizer.zero_grad()
    out = model(data)
    # Compute loss only on review nodes.
    loss = criterion(out[train_idx], data.y[train_idx])
    loss.backward()
    optimizer.step()

    if epoch % 20 == 0:
        print(f"Epoch: {epoch}, Training Loss: {loss.item():.4f}")

model.eval()
with torch.no_grad():
    pred = model(data)
    mse = criterion(pred[test_idx], data.y[test_idx]).item()
    mae = torch.mean(torch.abs(pred[test_idx] - data.y[test_idx])).item()
    print(f"Test MSE: {mse:.4f}, Test MAE: {mae:.4f}")

# Optionally, print out predictions for each review node in the test set.
for idx in test_idx.cpu().numpy():
    node_id = list(G.nodes())[idx]
    actual = data.y[idx].item()
    predicted = pred[idx].item()
    print(f"Review Node: {node_id} - Actual Rating: {actual}, Predicted Rating: {predicted:.2f}")

