from gensim.models import Word2Vec
from nltk.tokenize import word_tokenize
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.dummy import DummyClassifier
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.metrics import accuracy_score, mean_absolute_error, mean_squared_error, cohen_kappa_score
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.preprocessing import StandardScaler
import nltk
import numpy as np

nltk.download('punkt')

# === Load Data ===
data = pd.read_csv("HotelRec.csv")
reviews_text = data['text'].astype(str).tolist()
labels = data['rating']
tokenized_reviews = [word_tokenize(review.lower()) for review in reviews_text]

# === Helper for Word2Vec Vectorization ===
def get_review_vector(tokens, model):
    valid_tokens = [token for token in tokens if token in model.wv]
    if not valid_tokens:
        return np.zeros(model.vector_size)
    return np.mean([model.wv[token] for token in valid_tokens], axis=0)

# === Feature Extractors ===
def get_word2vec_vectors():
    model = Word2Vec(tokenized_reviews, vector_size=100, window=5, min_count=1, workers=4)
    return np.array([get_review_vector(tokens, model) for tokens in tokenized_reviews])

def get_bow_vectors():
    return CountVectorizer().fit_transform(reviews_text)

def get_tfidf_vectors():
    return TfidfVectorizer().fit_transform(reviews_text)

# === Evaluation ===
def evaluate_all_models(X, y, method_name=""):
    classifiers = {
        "Random Forest": RandomForestClassifier(),
        "Logistic Regression": LogisticRegression(max_iter=1000),
        "MLP Classifier": MLPClassifier(max_iter=500),
        "Dummy (Most Frequent)": DummyClassifier(strategy="most_frequent")
    }

    print(f"\n=== {method_name} (10-Fold CV) ===")

    # Detect if input is sparse (for BoW/TF-IDF)
    is_sparse = not isinstance(X, np.ndarray)

    results = {name: {"accuracy": [], "mae": [], "rmse": [], "kappa": []} for name in classifiers}

    kf = StratifiedKFold(n_splits=10, shuffle=True, random_state=42)
    for fold_idx, (train_idx, test_idx) in enumerate(kf.split(X, y)):
        print(f"\n--- Fold {fold_idx + 1} ---")

        X_train = X[train_idx] if is_sparse else X[train_idx, :]
        X_test = X[test_idx] if is_sparse else X[test_idx, :]
        y_train = y[train_idx]
        y_test = y[test_idx]

        for name, clf in classifiers.items():
            X_train_clf = X_train
            X_test_clf = X_test

            # Apply scaling only for dense inputs & relevant classifiers
            if not is_sparse and name in ["Logistic Regression", "MLP Classifier"]:
                scaler = StandardScaler()
                X_train_clf = scaler.fit_transform(X_train)
                X_test_clf = scaler.transform(X_test)

            clf.fit(X_train_clf, y_train)
            y_pred = clf.predict(X_test_clf)

            results[name]["accuracy"].append(accuracy_score(y_test, y_pred))
            results[name]["mae"].append(mean_absolute_error(y_test, y_pred))
            results[name]["rmse"].append(mean_squared_error(y_test, y_pred))
            results[name]["kappa"].append(cohen_kappa_score(y_test, y_pred))

    # Print average results
    for name in classifiers:
        print(f"\n{name} (Avg over 10 folds)")
        print(f"Accuracy: {np.mean(results[name]['accuracy']):.4f}")
        print(f"MAE: {np.mean(results[name]['mae']):.4f}")
        print(f"RMSE: {np.mean(results[name]['rmse']):.4f}")
        print(f"Cohen’s Kappa: {np.mean(results[name]['kappa']):.4f}")

# === Run Evaluations ===
evaluate_all_models(get_word2vec_vectors(), labels, method_name="Word2Vec")
evaluate_all_models(get_bow_vectors(), labels, method_name="Bag of Words")
evaluate_all_models(get_tfidf_vectors(), labels, method_name="TF-IDF")
