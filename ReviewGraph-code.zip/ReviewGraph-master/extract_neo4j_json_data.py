import json
import pandas as pd

filename = 'review_node2vec_5_extra_sentiment_features.json'

# Read and load json file to extract the data from it
with open(filename, 'r', encoding='utf-8-sig') as file:
    content = file.read()
    print("File content:", content)  # Debug step
    data = json.loads(content)

# If the file contains a list of entries, extract the entries and corresponding properties
rows = []
for entry in data:
    props = entry["N"]["properties"]

    flat_data = {
        "date": props["date"],
        "rating": props["rating"],
        "avg_sentiment": props.get("avg_sentiment", 0),
        "id": props["id"],
        "type": props["type"],
        "min_sentiment": props.get("min_sentiment", 0),
        "max_sentiment": props.get("max_sentiment", 0),
        "stdev_sentiment": props.get("stdev_sentiment", 0),
        "median_sentiment": props.get("median_sentiment", 0),
        "mode_sentiment": props.get("mode_sentiment", 0)
    }

    # Extract the node2vec values into separate features
    for idx, val in enumerate(props["node2Vec"]):
        flat_data[f"node2vec_{idx}"] = val

    rows.append(flat_data)

# Create a dataframe from the json data
df = pd.DataFrame(rows)
df.to_csv("review_node2vec_5_extra_sentiment_features.csv", index=False)